# Flutter specific
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }

# Kotlin
-keep class kotlin.** { *; }
-keep class kotlinx.** { *; }

# Image picker
-keep class androidx.exifinterface.** { *; }

# Record audio plugin
-keep class com.llfbandit.record.** { *; }

# Keep SIP app classes
-keep class com.sip.app.** { *; }

# Generic rules
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn okio.**
