import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Animated pulsing dot indicator
class PulseDot extends StatefulWidget {
  final Color color;
  final double size;

  const PulseDot({super.key, required this.color, this.size = 6});

  @override
  State<PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<PulseDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1500))
      ..repeat(reverse: true);
    _anim = Tween(begin: 1.0, end: 0.5).animate(
        CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _anim,
      builder: (_, __) => Container(
        width: widget.size,
        height: widget.size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: widget.color.withOpacity(_anim.value),
          boxShadow: [
            BoxShadow(
                color: widget.color.withOpacity(0.5),
                blurRadius: 6,
                spreadRadius: 1)
          ],
        ),
      ),
    );
  }
}

/// Floating particle background
class ParticleBackground extends StatefulWidget {
  const ParticleBackground({super.key});

  @override
  State<ParticleBackground> createState() => _ParticleBackgroundState();
}

class _ParticleBackgroundState extends State<ParticleBackground>
    with TickerProviderStateMixin {
  late List<AnimationController> _controllers;
  final _positions = <Offset>[];
  final _colors = <Color>[];

  @override
  void initState() {
    super.initState();
    const count = 18;
    _controllers = [];
    for (int i = 0; i < count; i++) {
      _positions.add(Offset(
        ((i * 37 + 11) % 100) / 100,
        ((i * 53 + 7) % 100) / 100,
      ));
      _colors.add(i % 4 == 0
          ? const Color(0x99B478FF)
          : i % 4 == 1
              ? const Color(0x80FFB450)
              : const Color(0x40FFFFFF));

      final ctrl = AnimationController(
        vsync: this,
        duration: Duration(seconds: 8 + (i % 5) * 2),
      )..repeat(reverse: true);
      _controllers.add(ctrl);
    }
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: SizedBox.expand(
        child: Stack(
          children: List.generate(_controllers.length, (i) {
            return AnimatedBuilder(
              animation: _controllers[i],
              builder: (_, __) {
                final t = _controllers[i].value;
                return Positioned(
                  left: _positions[i].dx * MediaQuery.of(context).size.width +
                      t * 8,
                  top: _positions[i].dy * MediaQuery.of(context).size.height -
                      t * 20,
                  child: Container(
                    width: i % 3 == 0 ? 2 : 1,
                    height: i % 3 == 0 ? 2 : 1,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _colors[i].withOpacity(0.3 + t * 0.5),
                    ),
                  ),
                );
              },
            );
          }),
        ),
      ),
    );
  }
}

/// Glow orb decoration
class GlowOrb extends StatelessWidget {
  final Color color;
  final double size;
  final double opacity;

  const GlowOrb(
      {super.key,
      required this.color,
      this.size = 300,
      this.opacity = 0.12});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color.withOpacity(opacity), Colors.transparent],
        ),
      ),
    );
  }
}

/// Section label above controls
class SectionLabel extends StatelessWidget {
  final String label;

  const SectionLabel({super.key, required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        label.toUpperCase(),
        style: const TextStyle(
          fontFamily: 'DMSans',
          fontSize: 10,
          letterSpacing: 3,
          color: AppColors.textDim,
        ),
      ),
    );
  }
}

/// Chip / pill selection button
class SipChip extends StatelessWidget {
  final String label;
  final bool active;
  final Color accentColor;
  final VoidCallback onTap;

  const SipChip({
    super.key,
    required this.label,
    required this.active,
    required this.accentColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: active ? accentColor.withOpacity(0.13) : AppColors.surface,
          borderRadius: BorderRadius.circular(100),
          border: Border.all(
            color:
                active ? accentColor.withOpacity(0.38) : AppColors.borderSubtle,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontFamily: 'DMSans',
            fontSize: 11,
            fontWeight: active ? FontWeight.w600 : FontWeight.w400,
            color: active ? accentColor : AppColors.textMuted,
            letterSpacing: 0.3,
          ),
        ),
      ),
    );
  }
}

/// Upload zone card
class UploadZoneCard extends StatelessWidget {
  final String label;
  final String icon;
  final String desc;
  final bool active;
  final VoidCallback onTap;

  const UploadZoneCard({
    super.key,
    required this.label,
    required this.icon,
    required this.desc,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: const ElasticOutCurve(0.8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: active
              ? const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0x2D9650FF), Color(0x1FFF8C32)],
                )
              : null,
          color: active ? null : AppColors.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: active
                ? const Color(0x80A059FF)
                : const Color(0x12FFFFFF),
          ),
        ),
        transform: active
            ? (Matrix4.identity()..scale(1.02))
            : Matrix4.identity(),
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(icon, style: const TextStyle(fontSize: 22)),
                const SizedBox(height: 6),
                Text(
                  label,
                  style: TextStyle(
                    fontFamily: 'Sora',
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color:
                        active ? const Color(0xFFD4AAFF) : AppColors.textSecondary,
                    letterSpacing: 0.3,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  desc,
                  style: const TextStyle(
                    fontFamily: 'DMSans',
                    fontSize: 10,
                    color: AppColors.textMuted,
                    letterSpacing: 0.2,
                  ),
                ),
              ],
            ),
            if (active)
              Positioned(
                top: 0,
                right: 0,
                child: PulseDot(color: AppColors.purple, size: 8),
              ),
          ],
        ),
      ),
    );
  }
}

/// Big gradient generate button
class GenerateButton extends StatefulWidget {
  final String label;
  final bool loading;
  final VoidCallback onTap;

  const GenerateButton({
    super.key,
    required this.label,
    required this.loading,
    required this.onTap,
  });

  @override
  State<GenerateButton> createState() => _GenerateButtonState();
}

class _GenerateButtonState extends State<GenerateButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _spinController;

  @override
  void initState() {
    super.initState();
    _spinController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat();
  }

  @override
  void dispose() {
    _spinController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.loading ? null : widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 24),
        decoration: BoxDecoration(
          gradient: widget.loading ? null : AppColors.brandGradient,
          color: widget.loading ? const Color(0x0DFFFFFF) : null,
          borderRadius: BorderRadius.circular(16),
          boxShadow: widget.loading
              ? []
              : [
                  BoxShadow(
                    color: AppColors.purpleDark.withOpacity(0.4),
                    blurRadius: 32,
                    offset: const Offset(0, 8),
                  ),
                ],
        ),
        child: widget.loading
            ? Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedBuilder(
                    animation: _spinController,
                    builder: (_, child) => Transform.rotate(
                      angle: _spinController.value * 6.28,
                      child: child,
                    ),
                    child: Container(
                      width: 16,
                      height: 16,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: Colors.white.withOpacity(0.2),
                          width: 2,
                        ),
                      ),
                      child: const Padding(
                        padding: EdgeInsets.all(1),
                        child: Align(
                          alignment: Alignment.topCenter,
                          child: SizedBox(
                            width: 12,
                            height: 6,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Colors.white, Colors.transparent],
                                ),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(6)),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Text(
                    'Processing Realism...',
                    style: TextStyle(
                      fontFamily: 'Sora',
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  PulseDot(color: Colors.white.withOpacity(0.9), size: 6),
                  const SizedBox(width: 8),
                  Text(
                    widget.label,
                    style: const TextStyle(
                      fontFamily: 'Sora',
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                      letterSpacing: 0.8,
                    ),
                  ),
                  const SizedBox(width: 8),
                  PulseDot(color: Colors.white.withOpacity(0.9), size: 6),
                ],
              ),
      ),
    );
  }
}

/// Glassmorphic card container
class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;
  final double borderRadius;
  final Color? borderColor;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.borderRadius = 16,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding ?? const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(
            color: borderColor ?? AppColors.borderSubtle, width: 1),
      ),
      child: child,
    );
  }
}

/// Styled prompt text field
class PromptTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final int maxLength;

  const PromptTextField({
    super.key,
    required this.controller,
    required this.hint,
    this.maxLength = 500,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderMuted),
      ),
      child: Column(
        children: [
          TextField(
            controller: controller,
            maxLines: 4,
            style: const TextStyle(
              fontFamily: 'DMSans',
              fontSize: 13,
              color: AppColors.textSecondary,
              height: 1.6,
              letterSpacing: 0.2,
            ),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(
                fontFamily: 'DMSans',
                fontSize: 13,
                color: AppColors.textDim,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(16),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 12, bottom: 10),
            child: Align(
              alignment: Alignment.centerRight,
              child: ValueListenableBuilder<TextEditingValue>(
                valueListenable: controller,
                builder: (_, v, __) => Text(
                  '${v.text.length} / $maxLength',
                  style: const TextStyle(
                    fontFamily: 'DMSans',
                    fontSize: 10,
                    color: AppColors.textDim,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
