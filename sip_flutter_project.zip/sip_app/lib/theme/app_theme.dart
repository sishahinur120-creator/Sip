import 'package:flutter/material.dart';

class AppColors {
  // Background
  static const Color background = Color(0xFF050210);
  static const Color surface = Color(0x08FFFFFF);
  static const Color surfaceBright = Color(0x0DFFFFFF);

  // Brand
  static const Color purple = Color(0xFFA050FF);
  static const Color purpleDark = Color(0xFF8040E8);
  static const Color orange = Color(0xFFE06030);
  static const Color pink = Color(0xFFC050A0);
  static const Color blue = Color(0xFF3090C0);
  static const Color green = Color(0xFF40E080);

  // Text
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xBFFFFFFF);
  static const Color textMuted = Color(0x59FFFFFF);
  static const Color textDim = Color(0x40FFFFFF);

  // Borders
  static const Color borderSubtle = Color(0x10FFFFFF);
  static const Color borderMuted = Color(0x12FFFFFF);

  // Page accent colors
  static const Color photoAccent = Color(0xFFA050FF);
  static const Color videoAccent = Color(0xFFC050A0);
  static const Color influencerAccent = Color(0xFFE06030);
  static const Color audioAccent = Color(0xFF3090C0);

  // Gradients
  static const LinearGradient brandGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF8040E8), Color(0xFFC060FF), Color(0xFFFF8040)],
    stops: [0.0, 0.5, 1.0],
  );

  static const LinearGradient photoGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0x30A050FF), Color(0x20FF8C32)],
  );

  static const LinearGradient influencerGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0x14FF8C3C), Color(0x14A050FF)],
  );
}

class AppTheme {
  static ThemeData get theme => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.purple,
          secondary: AppColors.orange,
          surface: AppColors.background,
        ),
        useMaterial3: true,
      );
}
