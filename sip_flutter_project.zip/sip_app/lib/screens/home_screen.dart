import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';

class HomePage extends StatefulWidget {
  final Function(int) onNavigate;

  const HomePage({super.key, required this.onNavigate});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  int? _hoveredIndex;

  final _features = const [
    _Feature(
      index: 1,
      label: 'Photo AI',
      sub: 'Hyperrealistic photo generation',
      icon: '📸',
      color: Color(0xFF7040D8),
    ),
    _Feature(
      index: 2,
      label: 'Video AI',
      sub: 'Cinematic motion synthesis',
      icon: '🎬',
      color: Color(0xFFC050A0),
    ),
    _Feature(
      index: 3,
      label: 'AI Influencer',
      sub: 'Create your digital identity',
      icon: '✦',
      color: Color(0xFFE06030),
    ),
    _Feature(
      index: 4,
      label: 'Audio AI',
      sub: 'Human-quality voice synthesis',
      icon: '🎙',
      color: Color(0xFF3090C0),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..forward();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  Animation<double> _delayedFade(double start, double end) {
    return Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animController,
        curve: Interval(start, end, curve: Curves.easeOut),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Hero
          FadeTransition(
            opacity: _delayedFade(0.0, 0.4),
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.3),
                end: Offset.zero,
              ).animate(CurvedAnimation(
                parent: _animController,
                curve: const Interval(0.0, 0.4, curve: Curves.easeOut),
              )),
              child: const _HeroSection(),
            ),
          ),

          const SizedBox(height: 8),

          // Feature grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.9,
            ),
            itemCount: _features.length,
            itemBuilder: (_, i) {
              final f = _features[i];
              return FadeTransition(
                opacity: _delayedFade(0.1 + i * 0.1, 0.5 + i * 0.1),
                child: _FeatureCard(
                  feature: f,
                  isHovered: _hoveredIndex == i,
                  onTap: () => widget.onNavigate(f.index),
                  onHoverChanged: (h) =>
                      setState(() => _hoveredIndex = h ? i : null),
                ),
              );
            },
          ),

          const SizedBox(height: 24),

          // Stats bar
          FadeTransition(
            opacity: _delayedFade(0.6, 0.9),
            child: const _StatsBar(),
          ),
        ],
      ),
    );
  }
}

class _HeroSection extends StatelessWidget {
  const _HeroSection();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 60, bottom: 40),
      child: Column(
        children: [
          const Text(
            'THE FUTURE OF CREATION',
            style: TextStyle(
              fontFamily: 'Sora',
              fontSize: 11,
              letterSpacing: 6,
              color: Color(0xCCA064FF),
            ),
          ),
          const SizedBox(height: 20),
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white, Color(0x99FFFFFF)],
            ).createShader(bounds),
            child: const Text(
              'SIP',
              style: TextStyle(
                fontFamily: 'Sora',
                fontSize: 68,
                fontWeight: FontWeight.w800,
                letterSpacing: -2,
                height: 0.9,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'SYNTHETIC INTELLIGENCE PLATFORM',
            style: TextStyle(
              fontFamily: 'DMSans',
              fontSize: 11,
              color: Color(0x59FFFFFF),
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 36),
          Wrap(
            spacing: 8,
            children: ['Portrait', 'Fashion', 'Cinematic', 'Street']
                .map((tag) => Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0x0AFFFFFF),
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(color: const Color(0x14FFFFFF)),
                      ),
                      child: Text(
                        tag,
                        style: const TextStyle(
                          fontFamily: 'DMSans',
                          fontSize: 11,
                          color: Color(0x80FFFFFF),
                          letterSpacing: 0.5,
                        ),
                      ),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final _Feature feature;
  final bool isHovered;
  final VoidCallback onTap;
  final ValueChanged<bool> onHoverChanged;

  const _FeatureCard({
    required this.feature,
    required this.isHovered,
    required this.onTap,
    required this.onHoverChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      onTapDown: (_) => onHoverChanged(true),
      onTapUp: (_) => onHoverChanged(false),
      onTapCancel: () => onHoverChanged(false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: const ElasticOutCurve(0.8),
        padding: const EdgeInsets.all(18),
        transform: isHovered
            ? (Matrix4.identity()
              ..translate(0.0, -4.0)
              ..scale(1.01))
            : Matrix4.identity(),
        decoration: BoxDecoration(
          gradient: isHovered
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    feature.color.withOpacity(0.13),
                    feature.color.withOpacity(0.07),
                  ],
                )
              : null,
          color: isHovered ? null : const Color(0x08FFFFFF),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isHovered
                ? feature.color.withOpacity(0.38)
                : const Color(0x0FFFFFFF),
          ),
        ),
        child: Stack(
          children: [
            // Background orb
            Positioned(
              top: -20,
              right: -20,
              child: Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      feature.color.withOpacity(0.06),
                      Colors.transparent
                    ],
                  ),
                ),
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  feature.icon,
                  style: const TextStyle(fontSize: 28),
                ),
                const SizedBox(height: 12),
                Text(
                  feature.label,
                  style: const TextStyle(
                    fontFamily: 'Sora',
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  feature.sub,
                  style: const TextStyle(
                    fontFamily: 'DMSans',
                    fontSize: 11,
                    color: Color(0x59FFFFFF),
                    height: 1.5,
                  ),
                ),
                const SizedBox(height: 16),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: isHovered ? 48 : 28,
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [feature.color, Colors.transparent],
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatsBar extends StatelessWidget {
  const _StatsBar();

  @override
  Widget build(BuildContext context) {
    const stats = [
      ('4K', 'Output Quality'),
      ('0.1s', 'Response Time'),
      ('∞', 'Possibilities'),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: const Color(0x08FFFFFF),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0x0FFFFFFF)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: stats.map((s) {
          return Column(
            children: [
              ShaderMask(
                shaderCallback: (b) => const LinearGradient(
                  colors: [Colors.white, Color(0xCCA064FF)],
                ).createShader(b),
                child: Text(
                  s.$1,
                  style: const TextStyle(
                    fontFamily: 'Sora',
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 2),
              Text(
                s.$2,
                style: const TextStyle(
                  fontFamily: 'DMSans',
                  fontSize: 10,
                  color: Color(0x4DFFFFFF),
                  letterSpacing: 0.5,
                ),
              ),
            ],
          );
        }).toList(),
      ),
    );
  }
}

class _Feature {
  final int index;
  final String label;
  final String sub;
  final String icon;
  final Color color;

  const _Feature({
    required this.index,
    required this.label,
    required this.sub,
    required this.icon,
    required this.color,
  });
}
