import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';

const _photoSections = [
  (id: 'face', label: 'Face', icon: '👤', desc: 'Skin, eyes, expression'),
  (id: 'body', label: 'Body', icon: '🧍', desc: 'Proportions, pose fix'),
  (id: 'hair', label: 'Hair / Hijab', icon: '💇', desc: 'Style, color, texture'),
  (id: 'shoes', label: 'Shoes', icon: '👟', desc: 'Footwear swap'),
  (id: 'dress', label: 'Outfit', icon: '👗', desc: 'Full clothing change'),
  (id: 'pose', label: 'Pose', icon: '🕺', desc: 'Body angle, stance'),
  (id: 'bg', label: 'Background', icon: '🌆', desc: 'Scene replacement'),
  (id: 'elements', label: 'Elements', icon: '✨', desc: 'Props, accessories'),
  (id: 'sunglass', label: 'Sunglasses', icon: '🕶️', desc: 'Eyewear overlay'),
  (id: 'lighting', label: 'Lighting', icon: '💡', desc: 'Cinematic grade'),
];

class PhotoScreen extends StatefulWidget {
  const PhotoScreen({super.key});

  @override
  State<PhotoScreen> createState() => _PhotoScreenState();
}

class _PhotoScreenState extends State<PhotoScreen> {
  String? _activeSection;
  bool _loading = false;
  final _promptController = TextEditingController();

  @override
  void dispose() {
    _promptController.dispose();
    super.dispose();
  }

  void _handleGenerate() {
    setState(() => _loading = true);
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          const Padding(
            padding: EdgeInsets.only(top: 32, bottom: 24),
            child: _PageHeader(
              eyebrow: 'Photo Studio',
              title: 'AI Photo Realism',
              accentColor: AppColors.photoAccent,
            ),
          ),

          // Upload zone
          _UploadMainPhoto(),
          const SizedBox(height: 20),

          // Section grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.6,
            ),
            itemCount: _photoSections.length,
            itemBuilder: (_, i) {
              final s = _photoSections[i];
              return UploadZoneCard(
                label: s.label,
                icon: s.icon,
                desc: s.desc,
                active: _activeSection == s.id,
                onTap: () => setState(() =>
                    _activeSection = _activeSection == s.id ? null : s.id),
              );
            },
          ),

          const SizedBox(height: 20),

          // Prompt
          PromptTextField(
            controller: _promptController,
            hint:
                'Describe your vision... cinematic portrait, golden hour, natural skin texture...',
          ),

          const SizedBox(height: 16),

          GenerateButton(
            label: 'Generate Cinematic Photo',
            loading: _loading,
            onTap: _handleGenerate,
          ),
        ],
      ),
    );
  }
}

class _UploadMainPhoto extends StatefulWidget {
  @override
  State<_UploadMainPhoto> createState() => _UploadMainPhotoState();
}

class _UploadMainPhotoState extends State<_UploadMainPhoto> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) => setState(() => _pressed = false),
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 180,
        decoration: BoxDecoration(
          color: _pressed
              ? const Color(0x14803CDC)
              : const Color(0x08FFFFFF),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: const Color(0x4DA064FF),
            style: BorderStyle.solid,
            width: 1.5,
          ),
        ),
        child: Stack(
          children: [
            // Radial glow
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFF803CDC).withOpacity(0.08),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('📷', style: TextStyle(fontSize: 32)),
                  const SizedBox(height: 10),
                  const Text(
                    'Upload Reference Photo',
                    style: TextStyle(
                      fontFamily: 'Sora',
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Color(0xBFFFFFFF),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'JPG, PNG, HEIC • Max 50MB',
                    style: TextStyle(
                      fontFamily: 'DMSans',
                      fontSize: 11,
                      color: AppColors.textDim,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PageHeader extends StatelessWidget {
  final String eyebrow;
  final String title;
  final Color accentColor;

  const _PageHeader({
    required this.eyebrow,
    required this.title,
    required this.accentColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          eyebrow.toUpperCase(),
          style: TextStyle(
            fontFamily: 'Sora',
            fontSize: 11,
            letterSpacing: 5,
            color: accentColor.withOpacity(0.7),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          title,
          style: const TextStyle(
            fontFamily: 'Sora',
            fontSize: 28,
            fontWeight: FontWeight.w800,
            color: Colors.white,
            letterSpacing: -0.5,
          ),
        ),
      ],
    );
  }
}

// Export _PageHeader for reuse
typedef PageHeader = _PageHeader;
