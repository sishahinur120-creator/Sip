import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';
import 'photo_screen.dart' show PageHeader;

const _ethnicityOptions = [
  'South Asian', 'East Asian', 'Middle Eastern',
  'African', 'European', 'Latin', 'Mixed',
];
const _beautyOptions = [
  'Cinematic', 'Editorial', 'Natural', 'Glam', 'Street', 'Luxury',
];
const _countryOptions = [
  'Pakistan', 'Bangladesh', 'India', 'UAE',
  'Turkey', 'Korea', 'Brazil', 'France',
];

class InfluencerScreen extends StatefulWidget {
  const InfluencerScreen({super.key});

  @override
  State<InfluencerScreen> createState() => _InfluencerScreenState();
}

class _InfluencerScreenState extends State<InfluencerScreen> {
  String _ethnicity = 'South Asian';
  String _beauty = 'Cinematic';
  String _country = 'Pakistan';
  double _age = 24;
  bool _loading = false;

  final Map<String, double> _sliders = {
    'jaw': 50,
    'cheek': 45,
    'eyes': 55,
    'nose': 48,
    'lip': 52,
  };

  void _handleGenerate() {
    setState(() => _loading = true);
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 32, bottom: 24),
            child: PageHeader(
              eyebrow: 'Influencer Lab',
              title: 'AI Identity Studio',
              accentColor: AppColors.influencerAccent,
            ),
          ),

          // Avatar preview
          _AvatarPreview(),
          const SizedBox(height: 20),

          // Ethnicity
          const SectionLabel(label: 'Ethnicity'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _ethnicityOptions
                .map((e) => SipChip(
                      label: e,
                      active: _ethnicity == e,
                      accentColor: AppColors.influencerAccent,
                      onTap: () => setState(() => _ethnicity = e),
                    ))
                .toList(),
          ),
          const SizedBox(height: 16),

          // Beauty style
          const SectionLabel(label: 'Beauty Style'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _beautyOptions
                .map((b) => SipChip(
                      label: b,
                      active: _beauty == b,
                      accentColor: AppColors.photoAccent,
                      onTap: () => setState(() => _beauty = b),
                    ))
                .toList(),
          ),
          const SizedBox(height: 16),

          // Country
          const SectionLabel(label: 'Country'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _countryOptions
                .map((c) => SipChip(
                      label: c,
                      active: _country == c,
                      accentColor: const Color(0xFF50A0E0),
                      onTap: () => setState(() => _country = c),
                    ))
                .toList(),
          ),
          const SizedBox(height: 20),

          // Age slider
          SectionLabel(label: 'Age: ${_age.round()}'),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 4,
              thumbColor: AppColors.influencerAccent,
              activeTrackColor: AppColors.influencerAccent,
              inactiveTrackColor: const Color(0x14FFFFFF),
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
            ),
            child: Slider(
              value: _age,
              min: 18,
              max: 45,
              onChanged: (v) => setState(() => _age = v),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text('18',
                  style: TextStyle(
                      fontFamily: 'DMSans',
                      fontSize: 10,
                      color: AppColors.textDim)),
              Text('45',
                  style: TextStyle(
                      fontFamily: 'DMSans',
                      fontSize: 10,
                      color: AppColors.textDim)),
            ],
          ),
          const SizedBox(height: 20),

          // Facial structure sliders
          const SectionLabel(label: 'Facial Structure'),
          ..._sliders.entries.map((entry) => _FacialSlider(
                label: entry.key,
                value: entry.value,
                onChanged: (v) =>
                    setState(() => _sliders[entry.key] = v),
              )),
          const SizedBox(height: 20),

          GenerateButton(
            label: 'Create AI Influencer',
            loading: _loading,
            onTap: _handleGenerate,
          ),
        ],
      ),
    );
  }
}

class _AvatarPreview extends StatefulWidget {
  @override
  State<_AvatarPreview> createState() => _AvatarPreviewState();
}

class _AvatarPreviewState extends State<_AvatarPreview>
    with TickerProviderStateMixin {
  late List<AnimationController> _ringControllers;

  @override
  void initState() {
    super.initState();
    _ringControllers = List.generate(3, (i) {
      return AnimationController(
        vsync: this,
        duration: Duration(milliseconds: 2000 + i * 500),
      )..repeat(reverse: true);
    });
  }

  @override
  void dispose() {
    for (final c in _ringControllers) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0x14FF8C3C), Color(0x14A050FF)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0x12FFFFFF)),
      ),
      child: Stack(
        children: [
          // Radial glow
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: RadialGradient(
                  center: const Alignment(0, -0.4),
                  colors: [
                    const Color(0x1AFF8C3C),
                    Colors.transparent,
                  ],
                  radius: 0.7,
                ),
              ),
            ),
          ),
          // Scanning rings
          ...List.generate(3, (i) {
            return AnimatedBuilder(
              animation: _ringControllers[i],
              builder: (_, __) {
                final v = _ringControllers[i].value;
                return Center(
                  child: Container(
                    width: 110.0 + i * 50,
                    height: 110.0 + i * 50,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Color.fromRGBO(
                            255, 140, 60, (0.15 / (i + 1)) * (0.3 + v * 0.7)),
                        width: 1,
                      ),
                    ),
                  ),
                );
              },
            );
          }),
          // Center content
          const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('✦', style: TextStyle(fontSize: 48, color: Colors.white)),
                SizedBox(height: 8),
                Text(
                  'YOUR AI IDENTITY',
                  style: TextStyle(
                    fontFamily: 'Sora',
                    fontSize: 12,
                    color: Color(0x59FFFFFF),
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FacialSlider extends StatelessWidget {
  final String label;
  final double value;
  final ValueChanged<double> onChanged;

  const _FacialSlider({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label[0].toUpperCase() + label.substring(1),
                style: const TextStyle(
                  fontFamily: 'DMSans',
                  fontSize: 11,
                  color: Color(0x73FFFFFF),
                ),
              ),
              Text(
                value.round().toString(),
                style: const TextStyle(
                  fontFamily: 'DMSans',
                  fontSize: 10,
                  color: AppColors.textDim,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Stack(
            alignment: Alignment.centerLeft,
            children: [
              Container(
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0x0FFFFFFF),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              FractionallySizedBox(
                widthFactor: value / 100,
                child: Container(
                  height: 4,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF8040E8), Color(0xFFE06030)],
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  trackHeight: 4,
                  thumbColor: AppColors.influencerAccent,
                  activeTrackColor: Colors.transparent,
                  inactiveTrackColor: Colors.transparent,
                  thumbShape:
                      const RoundSliderThumbShape(enabledThumbRadius: 6),
                  overlayShape:
                      const RoundSliderOverlayShape(overlayRadius: 12),
                ),
                child: Slider(
                  value: value,
                  min: 0,
                  max: 100,
                  onChanged: onChanged,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
