import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';
import 'photo_screen.dart' show PageHeader;

const _voiceStyles = ['Natural', 'Warm', 'Emotional', 'Cinematic', 'Luxury', 'Studio'];

class AudioScreen extends StatefulWidget {
  const AudioScreen({super.key});

  @override
  State<AudioScreen> createState() => _AudioScreenState();
}

class _AudioScreenState extends State<AudioScreen>
    with SingleTickerProviderStateMixin {
  bool _recording = false;
  bool _loading = false;
  String _selectedStyle = 'Natural';
  final _textController = TextEditingController();
  late AnimationController _waveController;

  @override
  void initState() {
    super.initState();
    _waveController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _textController.dispose();
    _waveController.dispose();
    super.dispose();
  }

  void _handleGenerate() {
    setState(() => _loading = true);
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 32, bottom: 24),
            child: PageHeader(
              eyebrow: 'Audio Studio',
              title: 'Voice Synthesis',
              accentColor: AppColors.audioAccent,
            ),
          ),

          // Waveform visualizer
          _WaveformVisualizer(recording: _recording),
          const SizedBox(height: 20),

          // Record button
          Center(
            child: GestureDetector(
              onTap: () => setState(() => _recording = !_recording),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                width: 72,
                height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: _recording
                      ? const LinearGradient(
                          colors: [Color(0xFFE04040), Color(0xFFA02020)],
                        )
                      : const LinearGradient(
                          colors: [Color(0x4D3090C0), Color(0x263090C0)],
                        ),
                  border: Border.all(
                    color: _recording
                        ? const Color(0x80FF5050)
                        : const Color(0x4D3090C0),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: (_recording
                              ? const Color(0xFFE04040)
                              : AppColors.audioAccent)
                          .withOpacity(0.4),
                      blurRadius: _recording ? 30 : 20,
                    ),
                  ],
                ),
                child: Center(
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    width: _recording ? 20 : 24,
                    height: _recording ? 20 : 24,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(_recording ? 4 : 12),
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Text input
          Container(
            decoration: BoxDecoration(
              color: const Color(0x08FFFFFF),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0x14FFFFFF)),
            ),
            child: TextField(
              controller: _textController,
              maxLines: 5,
              style: const TextStyle(
                fontFamily: 'DMSans',
                fontSize: 13,
                color: AppColors.textSecondary,
                height: 1.7,
              ),
              decoration: const InputDecoration(
                hintText:
                    'Type or speak your script... The voice will capture natural human emotion, breath, and warmth.',
                hintStyle: TextStyle(
                  fontFamily: 'DMSans',
                  fontSize: 13,
                  color: AppColors.textDim,
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.all(16),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Voice style chips
          const SectionLabel(label: 'Voice Style'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _voiceStyles
                .map((s) => SipChip(
                      label: s,
                      active: _selectedStyle == s,
                      accentColor: AppColors.audioAccent,
                      onTap: () => setState(() => _selectedStyle = s),
                    ))
                .toList(),
          ),
          const SizedBox(height: 20),

          GenerateButton(
            label: 'Synthesize Voice',
            loading: _loading,
            onTap: _handleGenerate,
          ),
        ],
      ),
    );
  }
}

class _WaveformVisualizer extends StatefulWidget {
  final bool recording;

  const _WaveformVisualizer({required this.recording});

  @override
  State<_WaveformVisualizer> createState() => _WaveformVisualizerState();
}

class _WaveformVisualizerState extends State<_WaveformVisualizer>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final _random = math.Random();

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        color: const Color(0x08FFFFFF),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0x263090C0)),
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: RadialGradient(
                  colors: [
                    const Color(0xFF3090C0).withOpacity(0.05),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _controller,
            builder: (_, __) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: List.generate(48, (i) {
                  final h = widget.recording
                      ? _random.nextDouble() * 60 + 10
                      : 4 +
                          (math.sin(i * 0.4) * math.sin(i * 0.4)) * 40 +
                          (math.cos(i * 0.7) * math.cos(i * 0.7)) * 20;
                  return Padding(
                    padding: const EdgeInsets.only(right: 2),
                    child: Container(
                      width: 3,
                      height: h,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color.fromRGBO(
                                48,
                                144,
                                192,
                                0.3 +
                                    (math.sin(i * 0.4) * math.sin(i * 0.4)) *
                                        0.5),
                            const Color(0x4DA050FF),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  );
                }),
              );
            },
          ),
        ],
      ),
    );
  }
}
