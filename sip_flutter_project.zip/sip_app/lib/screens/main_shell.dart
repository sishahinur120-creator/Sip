import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';
import 'home_screen.dart';
import 'photo_screen.dart';
import 'video_screen.dart';
import 'influencer_screen.dart';
import 'audio_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _currentIndex = 0;

  final _pages = <Widget>[];

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF050210),
      systemNavigationBarIconBrightness: Brightness.light,
    ));
  }

  List<Widget> _buildPages(Function(int) navigate) {
    return [
      HomePage(onNavigate: navigate),
      const PhotoScreen(),
      const VideoScreen(),
      const InfluencerScreen(),
      const AudioScreen(),
    ];
  }

  void _navigate(int index) {
    setState(() => _currentIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final pages = _buildPages(_navigate);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // Background atmosphere
          Positioned.fill(
            child: IgnorePointer(
              child: Stack(
                children: [
                  Positioned(
                    left: -40,
                    top: -20,
                    child: GlowOrb(
                      color: const Color(0xFF4020A0),
                      size: 400,
                      opacity: 0.15,
                    ),
                  ),
                  Positioned(
                    right: -60,
                    top: 200,
                    child: GlowOrb(
                      color: const Color(0xFFA04020),
                      size: 300,
                      opacity: 0.08,
                    ),
                  ),
                  Positioned(
                    left: 40,
                    bottom: 200,
                    child: GlowOrb(
                      color: const Color(0xFF2040A0),
                      size: 350,
                      opacity: 0.07,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Particles
          const ParticleBackground(),

          // Top accent line
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Container(
              height: 1,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    Color(0x66A050FF),
                    Color(0x4DFF8C3C),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // Content
          Column(
            children: [
              // App bar
              _SipAppBar(currentIndex: _currentIndex),

              // Page content
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  transitionBuilder: (child, anim) => FadeTransition(
                    opacity: anim,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: const Offset(0, 0.04),
                        end: Offset.zero,
                      ).animate(anim),
                      child: child,
                    ),
                  ),
                  child: KeyedSubtree(
                    key: ValueKey(_currentIndex),
                    child: pages[_currentIndex],
                  ),
                ),
              ),
            ],
          ),

          // Bottom nav
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: _BottomNav(
              currentIndex: _currentIndex,
              onTap: (i) => setState(() => _currentIndex = i),
            ),
          ),
        ],
      ),
    );
  }
}

class _SipAppBar extends StatelessWidget {
  final int currentIndex;

  const _SipAppBar({required this.currentIndex});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        left: 20,
        right: 20,
        bottom: 12,
      ),
      decoration: const BoxDecoration(
        color: Color(0xCC050210),
        border: Border(
          bottom: BorderSide(color: Color(0x0AFFFFFF)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          ShaderMask(
            shaderCallback: (b) => const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white, Color(0xE6A050FF)],
            ).createShader(b),
            child: const Text(
              'SIP',
              style: TextStyle(
                fontFamily: 'Sora',
                fontSize: 22,
                fontWeight: FontWeight.w800,
                letterSpacing: -0.5,
                color: Colors.white,
              ),
            ),
          ),
          Row(
            children: [
              PulseDot(color: AppColors.green, size: 6),
              const SizedBox(width: 8),
              const Text(
                'LIVE',
                style: TextStyle(
                  fontFamily: 'DMSans',
                  fontSize: 10,
                  color: Color(0xB340E080),
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _BottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const _BottomNav({required this.currentIndex, required this.onTap});

  static const _items = [
    _NavItem(label: 'Home', icon: Icons.home_outlined, activeIcon: Icons.home),
    _NavItem(label: 'Photo', icon: Icons.camera_alt_outlined, activeIcon: Icons.camera_alt),
    _NavItem(label: 'Video', icon: Icons.videocam_outlined, activeIcon: Icons.videocam),
    _NavItem(label: 'Influencer', icon: Icons.person_outline, activeIcon: Icons.person),
    _NavItem(label: 'Audio', icon: Icons.music_note_outlined, activeIcon: Icons.music_note),
  ];

  static const _accentColors = [
    AppColors.photoAccent,
    AppColors.photoAccent,
    AppColors.videoAccent,
    AppColors.influencerAccent,
    AppColors.audioAccent,
  ];

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    return Container(
      padding: EdgeInsets.fromLTRB(8, 12, 8, 20 + bottomPadding),
      decoration: const BoxDecoration(
        color: Color(0xD9050210),
        border: Border(top: BorderSide(color: Color(0x0FFFFFFF))),
      ),
      child: Row(
        children: List.generate(_items.length, (i) {
          final item = _items[i];
          final active = currentIndex == i;
          final color = _accentColors[i];

          return Expanded(
            child: GestureDetector(
              onTap: () => onTap(i),
              behavior: HitTestBehavior.opaque,
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 200),
                opacity: active ? 1.0 : 0.35,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AnimatedScale(
                      duration: const Duration(milliseconds: 200),
                      scale: active ? 1.1 : 1.0,
                      child: Icon(
                        active ? item.activeIcon : item.icon,
                        color: active ? color : const Color(0x80FFFFFF),
                        size: 22,
                      ),
                    ),
                    const SizedBox(height: 5),
                    if (active)
                      Container(
                        width: 4,
                        height: 4,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: color,
                          boxShadow: [
                            BoxShadow(color: color, blurRadius: 6),
                          ],
                        ),
                      )
                    else
                      const SizedBox(height: 4),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}

class _NavItem {
  final String label;
  final IconData icon;
  final IconData activeIcon;

  const _NavItem({
    required this.label,
    required this.icon,
    required this.activeIcon,
  });
}
