import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';
import 'photo_screen.dart' show PageHeader;

const _videoSections = [
  (id: 'orig', label: 'Source Video', icon: '🎬', desc: 'Upload your clip'),
  (id: 'photo', label: 'Face Swap', icon: '🪞', desc: 'Identity transfer'),
  (id: 'bg_v', label: 'Background', icon: '🌃', desc: 'Environment replace'),
  (id: 'outfit_v', label: 'Outfit', icon: '👔', desc: 'Style transform'),
  (id: 'audio_v', label: 'Audio Sync', icon: '🎵', desc: 'Voice & music'),
];

class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key});

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  String? _activeSection = 'orig';
  bool _loading = false;
  int _selectedQuality = 1; // 0=720p, 1=1080p, 2=4K

  void _handleGenerate() {
    setState(() => _loading = true);
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 32, bottom: 24),
            child: PageHeader(
              eyebrow: 'Video Studio',
              title: 'Cinematic Motion',
              accentColor: AppColors.videoAccent,
            ),
          ),

          // Timeline preview
          _TimelinePreview(),
          const SizedBox(height: 20),

          // Section grid
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 1.6,
            ),
            itemCount: _videoSections.length,
            itemBuilder: (_, i) {
              final s = _videoSections[i];
              return UploadZoneCard(
                label: s.label,
                icon: s.icon,
                desc: s.desc,
                active: _activeSection == s.id,
                onTap: () => setState(() =>
                    _activeSection = _activeSection == s.id ? null : s.id),
              );
            },
          ),

          const SizedBox(height: 16),

          // Quality selector
          Row(
            children: ['720p', '1080p', '4K'].asMap().entries.map((entry) {
              final i = entry.key;
              final q = entry.value;
              final selected = _selectedQuality == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selectedQuality = i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: EdgeInsets.only(
                      left: i == 0 ? 0 : 4,
                      right: i == 2 ? 0 : 4,
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      gradient: selected
                          ? const LinearGradient(
                              colors: [Color(0x40C850A0), Color(0x33A03CC8)],
                            )
                          : null,
                      color: selected ? null : const Color(0x0AFFFFFF),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: selected
                            ? const Color(0x66C850A0)
                            : const Color(0x12FFFFFF),
                      ),
                    ),
                    child: Center(
                      child: Text(
                        q,
                        style: TextStyle(
                          fontFamily: 'Sora',
                          fontSize: 12,
                          fontWeight:
                              selected ? FontWeight.w700 : FontWeight.w400,
                          color: selected
                              ? const Color(0xFFE080C0)
                              : const Color(0x59FFFFFF),
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),

          const SizedBox(height: 16),

          GenerateButton(
            label: 'Synthesize Cinematic Video',
            loading: _loading,
            onTap: _handleGenerate,
          ),
        ],
      ),
    );
  }
}

class _TimelinePreview extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0x08FFFFFF),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0x12FFFFFF)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'TIMELINE',
            style: TextStyle(
              fontFamily: 'DMSans',
              fontSize: 10,
              letterSpacing: 3,
              color: Color(0x40FFFFFF),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: List.generate(12, (i) {
              return Expanded(
                child: Container(
                  height: 32,
                  margin: EdgeInsets.only(right: i < 11 ? 4 : 0),
                  decoration: BoxDecoration(
                    gradient: i < 4
                        ? LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color.fromRGBO(160, 80, 255, 0.3 + i * 0.05),
                              const Color(0x3350268C),
                            ],
                          )
                        : null,
                    color: i < 4 ? null : const Color(0x0AFFFFFF),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: const Color(0x0DFFFFFF)),
                  ),
                ),
              );
            }),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: ['0:00', '0:05', '0:10', '0:15', '0:20']
                .map((t) => Text(
                      t,
                      style: const TextStyle(
                        fontFamily: 'DMSans',
                        fontSize: 9,
                        color: Color(0x33FFFFFF),
                      ),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }
}
