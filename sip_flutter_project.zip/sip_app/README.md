# SIP — Synthetic Intelligence Platform
## Flutter Android App

### Project Structure
```
sip_app/
├── lib/
│   ├── main.dart                    # App entry point
│   ├── theme/
│   │   └── app_theme.dart           # Colors, gradients, theme
│   ├── widgets/
│   │   └── shared_widgets.dart      # Reusable UI components
│   └── screens/
│       ├── main_shell.dart          # Bottom nav + app shell
│       ├── home_screen.dart         # Home / feature cards
│       ├── photo_screen.dart        # Photo AI studio
│       ├── video_screen.dart        # Video AI studio
│       ├── influencer_screen.dart   # AI Influencer creator
│       └── audio_screen.dart        # Voice synthesis
├── android/
│   ├── app/
│   │   ├── build.gradle
│   │   ├── proguard-rules.pro
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── kotlin/com/sip/app/MainActivity.kt
│   │       └── res/
│   │           ├── drawable/launch_background.xml
│   │           ├── values/styles.xml
│   │           ├── values/strings.xml
│   │           └── xml/
│   │               ├── file_paths.xml
│   │               └── network_security_config.xml
│   ├── build.gradle
│   ├── settings.gradle
│   ├── gradle.properties
│   └── gradle/wrapper/gradle-wrapper.properties
└── pubspec.yaml
```

### Setup & Run

1. **Prerequisites**
   - Flutter SDK ≥ 3.0.0: https://flutter.dev/docs/get-started/install
   - Android Studio with Android SDK (API 21+)
   - Java 17

2. **Create local.properties** (inside `android/` folder):
   ```
   sdk.dir=/path/to/your/Android/sdk
   flutter.sdk=/path/to/your/flutter
   flutter.buildMode=release
   flutter.versionName=1.0.0
   flutter.versionCode=1
   ```

3. **Install dependencies**:
   ```bash
   flutter pub get
   ```

4. **Add launcher icons** (optional but recommended):
   ```bash
   flutter pub add flutter_launcher_icons
   # Add icon image to assets/icon.png, configure pubspec.yaml, then:
   flutter pub run flutter_launcher_icons
   ```

5. **Run on device/emulator**:
   ```bash
   flutter run
   ```

6. **Build APK**:
   ```bash
   flutter build apk --release
   # Output: build/app/outputs/flutter-apk/app-release.apk
   ```

7. **Build App Bundle (for Play Store)**:
   ```bash
   flutter build appbundle --release
   # Output: build/app/outputs/bundle/release/app-release.aab
   ```

### App Screens
| Screen | Description |
|--------|-------------|
| Home | Feature cards, hero section, stats |
| Photo AI | Upload photo, select sections (Face/Body/Hair/etc.), prompt, generate |
| Video AI | Timeline preview, upload sections, quality selector, generate |
| AI Influencer | Ethnicity/beauty/country chips, age slider, facial sliders, generate |
| Audio AI | Waveform visualizer, mic record button, text input, voice style, generate |

### Customization
- Colors → `lib/theme/app_theme.dart`
- Add real API calls → inside `_handleGenerate()` methods in each screen
- Custom fonts → add to `pubspec.yaml` assets and `android/app/src/main/res/font/`
